import React from "react";

const OrderCard = ({ order }) => {
  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-xl font-semibold text-gray-800">Order #{order._id.slice(-6).toUpperCase()}</h3>
        <p
          className={`px-3 py-1 rounded-full text-sm font-semibold ${
            order.status === "pending"
              ? "bg-yellow-100 text-yellow-800"
              : order.status === "confirmed"
              ? "bg-green-100 text-green-800"
              : "bg-blue-100 text-blue-800"
          }`}
        >
          {order.status}
        </p>
      </div>
      <div className="space-y-2">
        {order.items.map((item) => (
          <div key={item.itemId._id} className="flex justify-between items-center">
            <div>
              <p className="text-gray-800 font-medium">{item.itemId.name}</p>
              <p className="text-gray-600">Quantity: {item.quantity}</p>
            </div>
            <p className="text-gray-800">${item.itemId.price * item.quantity}</p>
          </div>
        ))}
      </div>
      <div className="mt-4 pt-4 border-t border-gray-200">
        <p className="text-lg font-semibold text-gray-800">
          Total: ${order.totalPrice}
        </p>
      </div>
    </div>
  );
};

export default OrderCard;