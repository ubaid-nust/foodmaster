import { Link } from "react-router-dom";

const Navbar = () => {
  return (
    <nav className="bg-blue-600 text-white p-4 shadow-lg">
      <div className="container mx-auto flex justify-between items-center">
        <Link to="/" className="text-2xl font-bold">
          Admin Portal
        </Link>
        <div className="space-x-4">
          <Link to="/" className="hover:text-blue-200">
            Dashboard
          </Link>
          <Link to="/add-item" className="hover:text-blue-200">
            Add Item
          </Link>
          <Link to="/orders" className="hover:text-blue-200">
            Orders
          </Link>
          <Link to="/sign-in" className="hover:text-blue-200">
            Sign In
          </Link>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;