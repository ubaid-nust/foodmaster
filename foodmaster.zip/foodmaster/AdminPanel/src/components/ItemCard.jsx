import { Link } from "react-router-dom";
import axios from "axios";

const ItemCard = ({ item, onDelete }) => {
  const handleDelete = async () => {
    try {
      const token = localStorage.getItem('token');
      if (!token) {
        alert('Please sign in to delete items.');
        return;
      }

      // Confirm deletion
      const confirmDelete = window.confirm(`Are you sure you want to delete ${item.name}?`);
      if (!confirmDelete) return;

      // Send delete request
      const response = await axios.post(
        'http://localhost:3000/deleteItem',
        { _id: item._id }, // Send the item ID in the request body
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      console.log('Delete Item Response:', response.data);
      alert(response.data.message);

      // Call the onDelete function to update the parent component
      if (onDelete) {
        onDelete(item._id);
      }
    } catch (error) {
      console.error('Error deleting item:', error.response?.data || error.message);
      alert('Failed to delete item.');
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
      <img src={item.image} alt={item.name} className="w-full h-48 object-fill" />
      <div className="p-4">
        <h2 className="text-xl font-bold mb-2">{item.name}</h2>
        <p className="text-gray-700 mb-2">{item.description}</p>
        <p className="text-lg font-semibold text-blue-600">Rs.{item.price}</p>
        <div className="mt-4 flex space-x-2">
          <Link
            to={`/view-item/${item._id}`}
            className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors duration-300"
          >
            View
          </Link>
          <Link
            to={`/update-item/${item._id}`}
            className="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 transition-colors duration-300"
          >
            Update
          </Link>
          <button
            onClick={handleDelete}
            className="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 transition-colors duration-300"
          >
            Delete
          </button>
        </div>
      </div>
    </div>
  );
};

export default ItemCard;