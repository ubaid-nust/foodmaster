import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import Navbar from "../components/Navbar";

const UpdateItem = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [category, setCategory] = useState("");
  const [description, setDescription] = useState("");
  const [image, setImage] = useState(null);
  const [currentImage, setCurrentImage] = useState("");

  // Fetch the current item details
  useEffect(() => {
    const fetchItem = async () => {
      try {
        const response = await axios.get(`http://localhost:3000/api/items/${id}`);
        const item = response.data.item;
        setName(item.name);
        setPrice(item.price);
        setCategory(item.category);
        setDescription(item.description);
        setCurrentImage(item.image);
      } catch (error) {
        console.error("Error fetching item:", error);
      }
    };
    fetchItem();
  }, [id]);

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();

    // Create FormData object
    const formData = new FormData();
    formData.append("name", name);
    formData.append("price", parseFloat(price)); // Ensure price is a number
    formData.append("category", category);
    formData.append("description", description);
    if (image) formData.append("image", image); // Append image if provided

    try {
      // Send PUT request to update the item
      const response = await axios.put(
        `http://localhost:3000/admin/update-item/${id}`,
        formData,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
            "Content-Type": "multipart/form-data",
          },
        }
      );

      // Redirect to the dashboard after successful update
      navigate("/");
    } catch (error) {
      console.error("Error updating item:", error.response?.data || error.message);
      alert(error.response?.data?.message || "An error occurred while updating the item.");
    }
  };

  return (
    <div>
      <Navbar />
      <div className="p-6">
        <h1 className="text-2xl font-bold mb-6">Update Item</h1>
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Name Field */}
          <div>
            <label className="block text-sm font-medium mb-2">Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full p-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>

          {/* Price Field */}
          <div>
            <label className="block text-sm font-medium mb-2">Price</label>
            <input
              type="number"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              className="w-full p-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>

          {/* Category Field */}
          <div>
            <label className="block text-sm font-medium mb-2">Category</label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full p-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            >
              <option value="">Select Category</option>
              <option value="burger">Burger</option>
              <option value="sandwich">Sandwich</option>
              <option value="pizza">Pizza</option>
              <option value="drink">Drink</option>
              <option value="nuggets">Nuggets</option>
            </select>
          </div>

          {/* Description Field */}
          <div>
            <label className="block text-sm font-medium mb-2">Description</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full p-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>

          {/* Current Image */}
          <div>
            <label className="block text-sm font-medium mb-2">Current Image</label>
            <img src={currentImage} alt="Current Item" className="w-32 h-32 object-cover rounded-lg mb-4" />
          </div>

          {/* New Image Field */}
          <div>
            <label className="block text-sm font-medium mb-2">New Image (Optional)</label>
            <input
              type="file"
              onChange={(e) => setImage(e.target.files[0])}
              className="w-full p-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            className="w-full bg-blue-500 text-white p-2 rounded-lg hover:bg-blue-600 transition-colors duration-300"
          >
            Update Item
          </button>
        </form>
      </div>
    </div>
  );
};

export default UpdateItem;