import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";
import Navbar from "../components/Navbar";

const ViewItem = () => {
  const { id } = useParams();
  const [item, setItem] = useState(null);

  useEffect(() => {
    const fetchItem = async () => {
      try {
        const response = await axios.get(`http://localhost:3000/api/items/${id}`);
        setItem(response.data.item);
      } catch (error) {
        console.error("Error fetching item:", error);
      }
    };
    fetchItem();
  }, [id]);

  if (!item)
    return (
      <div className="flex justify-center items-center min-h-screen bg-gray-100">
        <p className="text-xl text-gray-800">Loading...</p>
      </div>
    );

  return (
    <div className="min-h-screen bg-gray-100">
      <Navbar />
      <div className="container mx-auto p-6">
        <h1 className="text-3xl font-bold text-gray-800 mb-8">View Item</h1>
        <div className="bg-white rounded-lg shadow-lg p-6 max-w-2xl mx-auto">
          <img
            src={item.image}
            alt={item.name}
            className="w-full h-96 object-cover rounded-lg mb-6"
          />
          <h2 className="text-2xl font-bold text-gray-800 mb-4">{item.name}</h2>
          <p className="text-gray-700 mb-4">{item.description}</p>
          <div className="space-y-2">
            <p className="text-lg font-semibold text-blue-600">${item.price}</p>
            <p className="text-gray-700">
              <span className="font-semibold">Category:</span> {item.category}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ViewItem;