import React, { useEffect, useState } from "react";
import axios from "axios";
import ItemCard from "../components/ItemCard";
import Navbar from "../components/Navbar";

const Dashboard = () => {
    const [items, setItems] = useState([]);

    useEffect(() => {
        const fetchItems = async () => {
            try {
                const response = await axios.get("http://localhost:3000/api/items");
                setItems(response.data.items);
            } catch (error) {
                console.error("Error fetching items:", error);
            }
        };
        fetchItems();
    }, []);

    const handleDeleteItem = (itemId) => {
        // Remove the deleted item from the state
        setItems((prevItems) => prevItems.filter((item) => item._id !== itemId));
    };

    return (
        <div className="min-h-screen bg-gray-100">
            <Navbar />
            <div className="container mx-auto p-6">
                <h1 className="text-3xl font-bold text-gray-800 mb-8">All Items</h1>
                {items.length === 0 ? (
                    <p className="text-gray-600 text-center">No items found.</p>
                ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                        {items.map((item) => (
                            <ItemCard key={item._id} item={item} onDelete={handleDeleteItem} />
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
};

export default Dashboard;