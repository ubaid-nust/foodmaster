import { useEffect, useState } from "react";
import axios from "axios";
import { useParams } from "react-router-dom";
import Navbar from "../components/Navbar";

const OrderDetails = () => {
  const { id } = useParams();
  const [order, setOrder] = useState(null);

  useEffect(() => {
    const fetchOrder = async () => {
      try {
        const response = await axios.get(`http://localhost:3000/admin/order/${id}`, {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        });
        setOrder(response.data.order);
      } catch (error) {
        console.error("Error fetching order:", error);
      }
    };
    fetchOrder();
  }, [id]);

  if (!order) return <div>Loading...</div>;

  return (
    <div>
      <Navbar />
      <div className="p-6">
        <h1 className="text-2xl font-bold mb-6">Order Details</h1>
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-bold">Order #{order._id.slice(-6)}</h2>
          <p className="text-gray-700 mt-2">Total: ${order.totalPrice}</p>
          <p className="text-gray-700">Location: {order.location}</p>
          <div className="mt-4">
            <h3 className="text-lg font-bold">Items:</h3>
            <ul className="space-y-2">
              {order.items.map((item) => (
                <li key={item.itemId._id} className="text-gray-700">
                  {item.itemId.name} - ${item.price} x {item.quantity}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrderDetails;