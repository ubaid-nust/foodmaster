import { useEffect, useState } from "react";
import axios from "axios";
import OrderCard from "../components/OrderCard";
import Navbar from "../components/Navbar";

const Orders = () => {
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const response = await axios.get("http://localhost:3000/admin/orders", {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        });
        setOrders(response.data.orders);
      } catch (error) {
        console.error("Error fetching orders:", error);
      }
    };
    fetchOrders();
  }, []);

  const handleAcceptOrder = async (orderId) => {
    try {
      await axios.put(
        `http://localhost:3000/admin/confirm-order/${orderId}`,
        {},
        { headers: { Authorization: `Bearer ${localStorage.getItem("token")}` } }
      );
      // Refresh orders after accepting
      const response = await axios.get("http://localhost:3000/admin/orders", {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });
      setOrders(response.data.orders);
    } catch (error) {
      console.error("Error accepting order:", error);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <Navbar />
      <div className="container mx-auto p-6">
        <h1 className="text-3xl font-bold text-gray-800 mb-8">All Orders</h1>
        <div className="space-y-6">
          {orders.map((order) => (
            <div
              key={order._id}
              className="bg-white rounded-lg shadow-lg p-6 hover:shadow-xl transition-shadow duration-300"
            >
              <OrderCard order={order} />
              <div className="mt-4">
                <p className="text-gray-700">
                  <span className="font-semibold">Phone:</span> {order.userId.phone}
                </p>
                <p className="text-gray-700">
                  <span className="font-semibold">Location:</span> {order.location}
                </p>
              </div>
              {order.status === "pending" && (
                <button
                  onClick={() => handleAcceptOrder(order._id)}
                  className="mt-4 bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 transition-colors duration-300"
                >
                  Accept Order
                </button>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Orders;