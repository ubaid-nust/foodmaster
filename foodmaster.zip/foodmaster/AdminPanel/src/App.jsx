import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import SignIn from "./pages/SignIn";
import Dashboard from "./pages/Dashboard";
import AddItem from "./pages/AddItem";
import ViewItem from "./pages/ViewItem";
import UpdateItem from "./pages/UpdateItem";
import Orders from "./pages/Orders";
import OrderDetails from "./pages/OrderDetails";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/sign-in" element={<SignIn />} />
        <Route path="/add-item" element={<AddItem />} />
        <Route path="/view-item/:id" element={<ViewItem />} />
        <Route path="/update-item/:id" element={<UpdateItem />} />
        <Route path="/orders" element={<Orders />} />
        <Route path="/order-details/:id" element={<OrderDetails />} />
      </Routes>
    </Router>
  );
}

export default App;