import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const Cart = () => {
  const [cart, setCart] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [location, setLocation] = useState(''); // State for location input
  const navigate = useNavigate();

  // Fetch cart items
  useEffect(() => {
    const fetchCart = async () => {
      try {
        const token = localStorage.getItem('token');
        const response = await axios.get('http://localhost:3000/user/cart', {
          headers: { Authorization: `Bearer ${token}` },
        });
        setCart(response.data.cart);
      } catch (err) {
        setError('Failed to fetch cart items.');
      } finally {
        setLoading(false);
      }
    };

    fetchCart();
  }, []);

  // Remove item from cart
  const handleRemoveItem = async (itemId) => {
    try {
      const token = localStorage.getItem('token');
      await axios.post(
        'http://localhost:3000/remove-from-cart',
        { itemId },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      // Refresh cart after removal
      const response = await axios.get('http://localhost:3000/user/cart', {
        headers: { Authorization: `Bearer ${token}` },
      });
      setCart(response.data.cart);
    } catch (err) {
      setError('Failed to remove item.');
    }
  };

  // Update item quantity
  const handleUpdateQuantity = async (itemId, quantity) => {
    try {
      const token = localStorage.getItem('token');
      await axios.put(
        'http://localhost:3000/user/update-cart',
        { itemId, quantity },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      // Refresh cart after update
      const response = await axios.get('http://localhost:3000/user/cart', {
        headers: { Authorization: `Bearer ${token}` },
      });
      setCart(response.data.cart);
    } catch (err) {
      setError('Failed to update quantity.');
    }
  };

  // Proceed to place order
  const handlePlaceOrder = async () => {
    if (!location) {
      setError('Please provide a delivery location.');
      return;
    }

    try {
      const token = localStorage.getItem('token');
      const items = cart.items.map((item) => ({
        itemId: item.itemId._id,
        quantity: item.quantity,
        price: item.itemId.price,
      }));
      const totalPrice = items.reduce((total, item) => total + item.price * item.quantity, 0);

      await axios.post(
        'http://localhost:3000/create-order',
        { items, totalPrice, location },
        { headers: { Authorization: `Bearer ${token}` } }
      );

      navigate('/orders'); // Navigate to orders page after placing order
    } catch (err) {
      setError('Failed to place order.');
    }
  };

  if (loading) return <div className="flex justify-center items-center min-h-screen">Loading...</div>;
  if (error) return <div className="text-red-500 text-center mt-4">{error}</div>;

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-6">Your Cart</h1>
      {cart?.items.length === 0 ? (
        <p className="text-gray-600">Your cart is empty.</p>
      ) : (
        <div>
          {cart?.items.map((item) => (
            <div key={item.itemId._id} className="border p-4 mb-4 flex justify-between items-center rounded-lg shadow-sm">
              <div>
                <h2 className="text-xl font-semibold">{item.itemId.name}</h2>
                <p>Price: ${item.itemId.price}</p>
                <img src={item.itemId.image} alt={item.itemId.name} className="w-20 h-20 mt-2 rounded-lg" />
              </div>
              <div>
                <input
                  type="number"
                  value={item.quantity}
                  onChange={(e) => handleUpdateQuantity(item.itemId._id, e.target.value)}
                  className="w-16 p-2 border rounded-lg"
                  min="1"
                />
                <button
                  onClick={() => handleRemoveItem(item.itemId._id)}
                  className="ml-4 bg-red-500 text-white p-2 rounded-lg hover:bg-red-600 transition-colors"
                >
                  Remove
                </button>
              </div>
            </div>
          ))}
          <div className="mt-6">
            <label className="block text-gray-700 font-semibold mb-2">Delivery Location</label>
            <input
              type="text"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder="Enter your delivery address"
              className="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>
          <button
            onClick={handlePlaceOrder}
            className="mt-6 w-full bg-green-500 text-white p-3 rounded-lg hover:bg-green-600 transition-colors"
          >
            Proceed to Order
          </button>
        </div>
      )}
    </div>
  );
};

export default Cart;