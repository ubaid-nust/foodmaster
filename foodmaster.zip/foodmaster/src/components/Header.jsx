import React from 'react';
import { Link, useNavigate } from 'react-router-dom';

const Header = () => {
  const navigate = useNavigate();
  const token = localStorage.getItem('token');

  const handleLogout = () => {
    localStorage.removeItem('token'); // Remove token from localStorage
    navigate('/sign-in'); // Redirect to sign-in page
  };

  return (
    <header className="bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-lg">
      <div className="container mx-auto flex justify-between items-center p-4">
        {/* Logo */}
        <Link to="/" className="text-3xl font-bold hover:text-blue-200 transition-colors duration-300">
          FoodMaster
        </Link>

        {/* Navigation */}
        <nav>
          <ul className="flex space-x-8 items-center">
            <li>
              <Link
                to="/menu"
                className="text-lg font-semibold hover:text-blue-200 transition-colors duration-300"
              >
                Menu
              </Link>
            </li>
            {token ? (
              <>
                <li>
                  <Link
                    to="/cart"
                    className="text-lg font-semibold hover:text-blue-200 transition-colors duration-300"
                  >
                    Cart
                  </Link>
                </li>
                <li>
                  <Link
                    to="/orders"
                    className="text-lg font-semibold hover:text-blue-200 transition-colors duration-300"
                  >
                    Orders
                  </Link>
                </li>
                <li>
                  <Link
                    to="/profile"
                    className="text-lg font-semibold hover:text-blue-200 transition-colors duration-300"
                  >
                    Profile
                  </Link>
                </li>
                <li>
                  <button
                    onClick={handleLogout}
                    className="text-lg font-semibold hover:text-blue-200 transition-colors duration-300"
                  >
                    Logout
                  </button>
                </li>
              </>
            ) : (
              <>
                <li>
                  <Link
                    to="/sign-up"
                    className="text-lg font-semibold hover:text-blue-200 transition-colors duration-300"
                  >
                    Sign Up
                  </Link>
                </li>
                <li>
                  <Link
                    to="/sign-in"
                    className="text-lg font-semibold hover:text-blue-200 transition-colors duration-300"
                  >
                    Sign In
                  </Link>
                </li>
              </>
            )}
          </ul>
        </nav>
      </div>
    </header>
  );
};

export default Header;