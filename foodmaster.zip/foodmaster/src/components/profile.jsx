import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const Profile = () => {
  const navigate = useNavigate();
  const token = localStorage.getItem('token');
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!token) {
      navigate('/sign-in');
      return;
    }

    const fetchProfile = async () => {
      try {
        const response = await axios.get('http://localhost:3000/user/profile', {
          headers: { Authorization: `Bearer ${token}` },
        });
        setUser(response.data.user);
      } catch (error) {
        setError('Failed to fetch profile data. Please try again.');
      } finally {
        setLoading(false);
      }
    };

    fetchProfile();
  }, [token, navigate]);

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen bg-gradient-to-r from-blue-50 to-purple-50">
        <div className="text-2xl font-semibold text-gray-700">Loading...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex justify-center items-center min-h-screen bg-gradient-to-r from-blue-50 to-purple-50">
        <div className="text-2xl font-semibold text-red-500">{error}</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-r from-blue-50 to-purple-50 py-12">
      <div className="container mx-auto px-4">
        <h2 className="text-4xl font-bold text-center text-gray-800 mb-8">Your Profile</h2>
        <div className="max-w-3xl mx-auto bg-white p-8 rounded-xl shadow-2xl transform transition-all hover:scale-105 hover:shadow-3xl">
          <div className="space-y-8">

            {/* User Details */}
            <div className="space-y-6">
              <div className="flex items-center">
                <span className="w-32 text-lg font-semibold text-gray-700">Name:</span>
                <span className="flex-1 text-lg text-gray-800">{user?.name}</span>
              </div>
              <div className="flex items-center">
                <span className="w-32 text-lg font-semibold text-gray-700">Email:</span>
                <span className="flex-1 text-lg text-gray-800">{user?.email}</span>
              </div>
              <div className="flex items-center">
                <span className="w-32 text-lg font-semibold text-gray-700">Phone:</span>
                <span className="flex-1 text-lg text-gray-800">{user?.phone}</span>
              </div>
            </div>

            {/* Update Profile Button */}
            <div className="flex justify-center">
              <button
                onClick={() => navigate('/update-profile')}
                className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-8 py-3 rounded-lg text-lg font-semibold hover:from-blue-700 hover:to-purple-700 transition-all transform hover:scale-105"
              >
                Update Profile
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;