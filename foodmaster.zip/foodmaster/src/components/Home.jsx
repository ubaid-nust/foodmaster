import React from 'react';
import { Link } from 'react-router-dom';

const Home = () => {
  return (
    <div className="bg-gray-100 py-12">
      <div className="container mx-auto text-center">
        <h1 className="text-4xl font-bold mb-4">Welcome to Foodie</h1>
        <p className="text-lg mb-8">Order your favorite food online!</p>
        <Link
          to="/menu"
          className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700"
        >
          Explore Menu
        </Link>
      </div>
    </div>
  );
};

export default Home;