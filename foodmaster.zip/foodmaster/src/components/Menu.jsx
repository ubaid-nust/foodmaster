import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';

const Menu = () => {
  const [items, setItems] = useState([]);
  const { category } = useParams();

  useEffect(() => {
    const fetchItems = async () => {
      try {
        const response = await axios.get("http://localhost:3000/api/items");
        console.log("API Response:", response.data); // Log the response
        setItems(response.data.items);
      } catch (error) {
        console.error("Error fetching items:", error.response?.data || error.message);
      }
    };
    fetchItems();
  }, []);

  useEffect(() => {
    console.log("Items state:", items); // Log the items state
  }, [items]);

  const handleAddToCart = async (itemId) => {
    try {
      const token = localStorage.getItem('token');
      if (!token) {
        alert('Please sign in to add items to the cart.');
        return;
      }

      const response = await axios.post(
        'http://localhost:3000/add-to-cart',
        { itemId, quantity: 1 }, // Default quantity is 1
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      console.log('Add to Cart Response:', response.data);
      alert('Item added to cart successfully!');
    } catch (error) {
      console.error('Error adding to cart:', error.response?.data || error.message);
      alert('Failed to add item to cart.');
    }
  };

  return (
    <div className="container mx-auto p-4">
      <h2 className="text-2xl font-bold mb-6">
        {category ? `${category.charAt(0).toUpperCase() + category.slice(1)}` : 'Menu'}
      </h2>
      {items.length === 0 ? (
        <p className="text-gray-600">No items found.</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {items.map((item) => (
            <div key={item._id} className="bg-white p-6 rounded-lg shadow-md">
              <img
                src={item.image}
                alt={item.name}
                className="w-full h-48 object-cover rounded-md mb-4"
              />
              <h3 className="text-xl font-semibold mb-2">{item.name}</h3>
              <p className="text-gray-600 mb-2">${item.price}</p>
              <p className="text-gray-600 mb-4">{item.description}</p>
              <button
                className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
                onClick={() => handleAddToCart(item._id)}
              >
                Add to Cart
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Menu;