import React, { useEffect, useState } from 'react';
import axios from 'axios';

const Orders = () => {
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const token = localStorage.getItem('token');
        const response = await axios.get('http://localhost:3000/user/orders', {
          headers: { Authorization: `Bearer ${token}` },
        });
        setOrders(response.data.orders);
      } catch (error) {
        console.error('Error fetching orders:', error);
      }
    };
    fetchOrders();
  }, []);

  return (
    <div className="min-h-screen bg-gray-100 py-8">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-gray-800 mb-8">Your Orders</h2>
        <div className="space-y-6">
          {orders.length === 0 ? (
            <p className="text-gray-600 text-center">No orders found.</p>
          ) : (
            orders.map((order) => (
              <div
                key={order._id}
                className="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition-shadow duration-300"
              >
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-xl font-semibold text-gray-800">
                    Order #{order._id.slice(-6).toUpperCase()}
                  </h3>
                  <p
                    className={`px-3 py-1 rounded-full text-sm font-semibold ${
                      order.status === 'pending'
                        ? 'bg-yellow-100 text-yellow-800'
                        : order.status === 'confirmed'
                        ? 'bg-green-100 text-green-800'
                        : 'bg-blue-100 text-blue-800'
                    }`}
                  >
                    {order.status}
                  </p>
                </div>
                <div className="space-y-2">
                  <p className="text-gray-700">
                    <span className="font-semibold">Total:</span> ${order.totalPrice}
                  </p>
                  <p className="text-gray-700">
                    <span className="font-semibold">Location:</span> {order.location}
                  </p>
                </div>
                <div className="mt-4 pt-4 border-t border-gray-200">
                  <h4 className="text-lg font-semibold text-gray-800 mb-2">Items:</h4>
                  {order.items.map((item) => (
                    <div key={item.itemId._id} className="flex justify-between items-center mb-2">
                      <p className="text-gray-700">{item.itemId.name}</p>
                      <p className="text-gray-700">
                        {item.quantity} x ${item.price}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default Orders;