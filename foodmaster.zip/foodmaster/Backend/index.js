const port = 3000;
const express = require('express');
const app = express();
const mongoose = require('mongoose');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
require('dotenv').config();
app.use(express.json());

app.use(cors({
    origin: ['http://localhost:5173', 'http://localhost:5174'],
    credentials: true
}));

const jwt_secret = process.env.JWT_SECRET;

const URL = process.env.MONGO_URI || 'mongodb+srv://ubaid:6734ubaid@cluster.n3wrm.mongodb.net/?retryWrites=true&w=majority&appName=cluster';
mongoose.connect(URL)
    .then(() => console.log("Connected to MongoDB."))
    .catch(error => console.log(error));

// User Schema
const UserSchema = new mongoose.Schema({
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    phone: { type: String, required: true, unique: true },
    password: { type: String, required: true }
});
const User = mongoose.model('User', UserSchema);

// Admin Schema
const AdminSchema = new mongoose.Schema({
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true }
});
const Admin = mongoose.model('Admin', AdminSchema);

// Item Schema
const ItemsSchema = new mongoose.Schema({
    name: { type: String, required: true },
    price: { type: Number, required: true },
    category: { type: String, required: true, enum: ['burger', 'sandwich', 'pizza', 'drink', 'nuggets'] },
    description: { type: String, required: true },
    image: { type: String, required: true }
}, { timestamps: true });

const Item = mongoose.model('Item', ItemsSchema);

// Cart Schema
const cartSchema = new mongoose.Schema({
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    items: [{
        itemId: { type: mongoose.Schema.Types.ObjectId, ref: 'Item', required: true },
        quantity: { type: Number, default: 1 }
    }]
});

const Cart = mongoose.model('Cart', cartSchema);

// Order Schema
const orderSchema = new mongoose.Schema({
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    items: [{
        itemId: { type: mongoose.Schema.Types.ObjectId, ref: 'Item', required: true },
        quantity: { type: Number, required: true },
        price: { type: Number, required: true } // Price of the item at the time of ordering
    }],
    totalPrice: { type: Number, required: true },
    location: { type: String, required: true }, // Delivery address for this order
    status: { type: String, enum: ['pending', 'confirmed', 'delivered'], default: 'pending' },
    createdAt: { type: Date, default: Date.now }
});

const Order = mongoose.model('Order', orderSchema);

// Static folder for serving images
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Multer Storage Configuration
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads/');
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + path.extname(file.originalname));
    }
});

const upload = multer({ storage });;

// Middleware to authenticate admin
const authenticateAdmin = async (req, res, next) => {
    const admin = await Admin.findOne({ email: req.user.email });
    if (!admin) {
        return res.status(403).json({ message: "Access denied. Admin privileges required." });
    }
    next();
};

// Middleware to verify JWT token
const verifyToken = (req, res, next) => {
    const token = req.headers.authorization?.split(" ")[1];
    if (!token) return res.status(401).json({ message: "Unauthorized access." });

    jwt.verify(token, process.env.JWT_SECRET, (err, decoded) => {
        if (err) return res.status(401).json({ message: "Invalid token." });
        req.user = decoded;
        next();
    });
};

// Example of a protected admin route
app.get('/admin/dashboard', verifyToken, authenticateAdmin, async (req, res) => {
    try {
        const orders = await Order.find().populate('userId', 'name email').populate('items.itemId', 'name price');
        return res.status(200).json({ orders });
    } catch (error) {
        return res.status(500).json({ message: 'Error fetching orders.', error: error.message });
    }
});

// Admin Sign-Up Route
app.post('/admin/sign-up', async (req, res) => {
    try {
        const { email, password } = req.body;

        // Check if admin already exists
        const existingAdmin = await Admin.findOne({ email });
        if (existingAdmin) {
            return res.status(400).json({ message: "Admin with this email already exists." });
        }

        // Hash password
        const hashedPassword = await bcrypt.hash(password, 10);

        // Create new admin
        const newAdmin = new Admin({ email, password: hashedPassword });
        await newAdmin.save();

        return res.status(201).json({ message: 'Admin signed up successfully.' });
    } catch (error) {
        return res.status(500).json({ message: 'Error signing up admin.', error: error.message });
    }
});

// Admin Sign-In Route
app.post('/admin/sign-in', async (req, res) => {
    try {
        const { email, password } = req.body;

        // Find admin by email
        const admin = await Admin.findOne({ email });
        if (!admin) {
            return res.status(404).json({ message: "Admin not found." });
        }

        // Verify password
        const isMatch = await bcrypt.compare(password, admin.password);
        if (!isMatch) {
            return res.status(400).json({ message: "Wrong password." });
        }

        // Generate JWT token
        const token = jwt.sign({ userId: admin._id, email: admin.email }, process.env.JWT_SECRET);

        return res.status(200).json({ message: 'Admin login successful.', token });
    } catch (error) {
        return res.status(500).json({ message: 'Admin login failed.', error: error.message });
    }
});

// User Sign-Up Route
app.post('/sign-up', async (req, res) => {
    try {
        const { name, email, phone, password } = req.body;
        if (!name || !email || !phone || !password) {
            return res.status(400).json({ message: "All fields are required." });
        }

        // Check if user already exists
        const existingUser = await User.findOne({ $or: [{ email }, { phone }] });
        if (existingUser) {
            return res.status(400).json({ message: `User with email ${email} or phone ${phone} already exists.` });
        }

        // Hash password
        const hashedPassword = await bcrypt.hash(password, 10);

        // Create new user
        const newUser = new User({ name, email, phone, password: hashedPassword });
        await newUser.save();

        return res.status(201).json({ message: 'User signed up successfully.', user: { name: newUser.name, email: newUser.email } });
    } catch (error) {
        return res.status(500).json({ message: 'Error signing up user.', error: error.message });
    }
});

// User Sign-In Route
app.post('/sign-in', async (req, res) => {
    try {
        const { email, password } = req.body;

        // Find user by email
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(404).json({ message: "User not found." });
        }

        // Verify password
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(400).json({ message: "Wrong password." });
        }

        // Generate JWT token
        const token = jwt.sign({ userId: user._id, email: user.email }, process.env.JWT_SECRET);

        return res.status(200).json({ message: 'Login successful.', user: { name: user.name, email: user.email }, token });
    } catch (error) {
        return res.status(500).json({ message: 'Login failed.', error: error.message });
    }
});

// Logout route
app.post('/logout', verifyToken, async (req, res) => {
    try {
        const token = req.headers.authorization?.split(" ")[1];
        if (!token) {
            return res.status(401).json({ message: "No token provided." });
        }

        // In a production environment, you would add the token to a blacklist in a database or Redis
        return res.status(200).json({ message: "Logout successful." });
    } catch (error) {
        return res.status(500).json({ message: "Logout failed.", error: error.message });
    }
});

// Add item route
app.post('/addItem', verifyToken, authenticateAdmin, upload.single('image'), async (req, res) => {
    try {
        const { name, price, category, description } = req.body;
        const imageURL = req.file ? `http://localhost:3000/uploads/${req.file.filename}` : '';

        const newItem = new Item({ name, price, category, description, image: imageURL });
        await newItem.save();

        return res.status(201).json({ message: 'Item added successfully', item: newItem });
    } catch (error) {
        return res.status(500).json({ message: "Error adding item", error: error.message });
    }
});

// Fetch all items
app.get('/api/items', async (req, res) => {
    try {
        const items = await Item.find();
        res.status(200).json({ items });
    } catch (error) {
        res.status(500).json({ message: 'Error fetching items.', error: error.message });
    }
});

// Fetch items by category
app.get('/api/items/category/:category', async (req, res) => {
    try {
        const { category } = req.params;
        const items = await Item.find({ category });
        res.status(200).json({ items });
    } catch (error) {
        res.status(500).json({ message: 'Error fetching items by category.', error: error.message });
    }
});

// Delete item route
app.post('/deleteItem', verifyToken, authenticateAdmin, async (req, res) => {
    try {
        const itemFound = await Item.findById(req.body._id);
        if (!itemFound) {
            return res.status(404).json({ message: "Item not found" });
        }

        await Item.findByIdAndDelete(req.body._id);
        return res.status(200).json({ message: `Item ${itemFound.name} deleted successfully from the database.` });
    } catch (error) {
        return res.status(500).json({ message: "Internal server error", error: error.message });
    }
});

// Add to cart route
app.post('/add-to-cart', verifyToken, async (req, res) => {
    try {
        const userId = req.user.userId;
        const { itemId, quantity } = req.body;

        const item = await Item.findById(itemId);
        if (!item) {
            return res.status(404).json({ message: 'Item not available.' });
        }

        let cart = await Cart.findOne({ userId });
        if (!cart) {
            cart = new Cart({ userId, items: [] });
        }

        const existingItem = cart.items.find(item => item.itemId.toString() === itemId);
        if (existingItem) {
            existingItem.quantity += quantity || 1;
        } else {
            cart.items.push({ itemId, quantity: quantity || 1 });
        }

        await cart.save();
        return res.status(201).json({ message: 'Item added to the cart successfully.' });
    } catch (error) {
        return res.status(500).json({ message: 'Internal server error.', error: error.message });
    }
});

// Remove from cart route
app.post('/remove-from-cart', verifyToken, async (req, res) => {
    try {
        const userId = req.user.userId;
        const { itemId } = req.body;

        let cart = await Cart.findOne({ userId });
        if (!cart) {
            return res.status(404).json({ message: "Cart not found." });
        }

        const itemIndex = cart.items.findIndex(item => item.itemId.toString() === itemId);
        if (itemIndex === -1) {
            return res.status(400).json({ message: "Item not found in cart." });
        }

        cart.items.splice(itemIndex, 1);
        await cart.save();

        return res.status(200).json({ message: 'Item successfully removed from the cart.' });
    } catch (error) {
        return res.status(500).json({ message: 'Internal server error.', error: error.message });
    }
});

// Fetch cart items for a user
app.get('/user/cart', verifyToken, async (req, res) => {
    try {
      const userId = req.user.userId;
  
      // Find the user's cart and populate item details
      const cart = await Cart.findOne({ userId }).populate('items.itemId', 'name price image');
  
      if (!cart) {
        return res.status(404).json({ message: "Cart not found." });
      }
  
      return res.status(200).json({ cart });
    } catch (error) {
      return res.status(500).json({ message: 'Error fetching cart.', error: error.message });
    }
  });

// Update item route
app.put('/admin/update-item/:itemId', verifyToken, authenticateAdmin, upload.single('image'), async (req, res) => {
    try {
        const { itemId } = req.params;
        const { name, price, category, description } = req.body;
        const image = req.file ? `http://localhost:3000/uploads/${req.file.filename}` : null;

        // Validate input
        if (!name || !price || !category || !description) {
            return res.status(400).json({ message: "All fields are required." });
        }

        // Update the item
        const updatedItem = await Item.findByIdAndUpdate(
            itemId,
            { name, price, category, description, ...(image && { image }) }, // Only update image if a new one is provided
            { new: true }
        );

        if (!updatedItem) {
            return res.status(404).json({ message: "Item not found." });
        }

        res.json({ message: "Item updated successfully.", item: updatedItem });
    } catch (err) {
        res.status(500).json({ message: "Database error", error: err.message });
    }
});

// Update cart route
app.put("/user/update-cart", verifyToken, async (req, res) => {
    try {
        const { itemId, quantity } = req.body;
        const userId = req.user.userId;

        if (!itemId || !quantity || isNaN(quantity)) {
            return res.status(400).json({ message: "Invalid input." });
        }

        const cart = await Cart.findOne({ userId });
        if (!cart) {
            return res.status(404).json({ message: "Cart not found." });
        }

        const cartItem = cart.items.find(item => item.itemId.toString() === itemId);
        if (!cartItem) {
            return res.status(404).json({ message: "Item not found in cart." });
        }

        cartItem.quantity = quantity;
        await cart.save();

        res.json({ message: "Cart updated successfully.", cart });
    } catch (err) {
        res.status(500).json({ message: "Database error", error: err.message });
    }
});

// Get user profile route
app.get("/user/profile", verifyToken, async (req, res) => {
    try {
        const userId = req.user.userId;
        const user = await User.findById(userId).select("-password");

        if (!user) {
            return res.status(404).json({ message: "User not found." });
        }

        res.json({ user });
    } catch (err) {
        res.status(500).json({ message: "Database error", error: err.message });
    }
});

// Update user profile route
app.put("/user/update-profile", verifyToken, async (req, res) => {
    try {
        const userId = req.user.userId;
        const { name, email, phone } = req.body;

        const updatedUser = await User.findByIdAndUpdate(userId, { name, email, phone }, { new: true }).select("-password");

        if (!updatedUser) {
            return res.status(404).json({ message: "User not found." });
        }

        res.json({ message: "Profile updated successfully.", user: updatedUser });
    } catch (err) {
        res.status(500).json({ message: "Database error", error: err.message });
    }
});

app.post('/create-order', verifyToken, async (req, res) => {
    try {
        const { items, totalPrice, location } = req.body;
        const userId = req.user.userId;

        // Validate input
        if (!items || !Array.isArray(items)) {
            return res.status(400).json({ message: "Invalid items provided." });
        }
        if (!totalPrice || isNaN(totalPrice)) {
            return res.status(400).json({ message: "Invalid total price provided." });
        }
        if (!location) {
            return res.status(400).json({ message: "Delivery location is required." });
        }

        // Create the order
        const newOrder = new Order({
            userId,
            items,
            totalPrice,
            location,
            status: 'pending'
        });

        await newOrder.save();

        return res.status(201).json({ message: 'Order created successfully.', order: newOrder });
    } catch (error) {
        return res.status(500).json({ message: 'Error creating order.', error: error.message });
    }
});

// Update Order Status
app.put('/admin/update-order-status/:orderId', verifyToken, authenticateAdmin, async (req, res) => {
    try {
        const { orderId } = req.params;
        const { status } = req.body;

        if (!['pending', 'confirmed', 'delivered'].includes(status)) {
            return res.status(400).json({ message: "Invalid status provided." });
        }

        const order = await Order.findByIdAndUpdate(orderId, { status }, { new: true })
            .populate('userId', 'name email')
            .populate('items.itemId', 'name price');

        if (!order) {
            return res.status(404).json({ message: "Order not found." });
        }

        return res.status(200).json({ message: 'Order status updated successfully.', order });
    } catch (error) {
        return res.status(500).json({ message: 'Error updating order status.', error: error.message });
    }
});

// Backend API to fetch a single item
app.get('/api/items/:itemId', async (req, res) => {
    try {
        const item = await Item.findById(req.params.itemId);
        if (!item) {
            return res.status(404).json({ message: "Item not found." });
        }
        res.status(200).json({ item });
    } catch (error) {
        res.status(500).json({ message: 'Error fetching item.', error: error.message });
    }
});

app.put('/admin/confirm-order/:orderId', verifyToken, authenticateAdmin, async (req, res) => {
    try {
        const { orderId } = req.params;

        const order = await Order.findById(orderId);
        if (!order) {
            return res.status(404).json({ message: "Order not found." });
        }

        if (order.status !== 'pending') {
            return res.status(400).json({ message: "Order is already confirmed or delivered." });
        }

        order.status = 'confirmed';
        await order.save();

        return res.status(200).json({ message: 'Order confirmed successfully.', order });
    } catch (error) {
        return res.status(500).json({ message: 'Error confirming order.', error: error.message });
    }
});

app.put('/admin/deliver-order/:orderId', verifyToken, authenticateAdmin, async (req, res) => {
    try {
        const { orderId } = req.params;

        const order = await Order.findById(orderId);
        if (!order) {
            return res.status(404).json({ message: "Order not found." });
        }

        if (order.status !== 'confirmed') {
            return res.status(400).json({ message: "Order must be confirmed before marking as delivered." });
        }

        order.status = 'delivered';
        await order.save();

        return res.status(200).json({ message: 'Order marked as delivered successfully.', order });
    } catch (error) {
        return res.status(500).json({ message: 'Error delivering order.', error: error.message });
    }
});

app.get('/admin/orders', verifyToken, authenticateAdmin, async (req, res) => {
    try {
      const orders = await Order.find()
        .populate('userId', 'name email phone') // Populate userId with name, email, and phone
        .populate('items.itemId', 'name price'); // Populate itemId with name and price
  
      return res.status(200).json({ orders });
    } catch (error) {
      return res.status(500).json({ message: 'Error fetching orders.', error: error.message });
    }
  });

app.get('/admin/order/:orderId', verifyToken, authenticateAdmin, async (req, res) => {
    try {
        const { orderId } = req.params;

        const order = await Order.findById(orderId)
            .populate('userId', 'name email')
            .populate('items.itemId', 'name price');

        if (!order) {
            return res.status(404).json({ message: "Order not found." });
        }

        return res.status(200).json({ order });
    } catch (error) {
        return res.status(500).json({ message: 'Error fetching order.', error: error.message });
    }
});

app.get('/user/orders', verifyToken, async (req, res) => {
    try {
        const userId = req.user.userId;

        const orders = await Order.find({ userId })
            .populate('items.itemId', 'name price');

        return res.status(200).json({ orders });
    } catch (error) {
        return res.status(500).json({ message: 'Error fetching user orders.', error: error.message });
    }
});

app.put('/user/update-location', verifyToken, async (req, res) => {
    try {
        const userId = req.user.userId;
        const { location } = req.body;

        if (!location) {
            return res.status(400).json({ message: "Location is required." });
        }

        const user = await User.findByIdAndUpdate(userId, { location }, { new: true });
        if (!user) {
            return res.status(404).json({ message: "User not found." });
        }

        return res.status(200).json({ message: 'Location updated successfully.', user });
    } catch (error) {
        return res.status(500).json({ message: 'Error updating location.', error: error.message });
    }
});

app.get('/search-items', async (req, res) => {
    try {
        const { query, category, minPrice, maxPrice } = req.query;
        const searchCriteria = {};

        if (query) {
            searchCriteria.name = { $regex: query, $options: 'i' };
        }
        if (category) {
            searchCriteria.category = category;
        }
        if (minPrice || maxPrice) {
            searchCriteria.price = {};
            if (minPrice) searchCriteria.price.$gte = parseFloat(minPrice);
            if (maxPrice) searchCriteria.price.$lte = parseFloat(maxPrice);
        }

        const items = await Item.find(searchCriteria);
        res.status(200).json({ items });
    } catch (error) {
        res.status(500).json({ message: 'Error searching itemss.', error: error.message });
    }
});

// Root route
app.get('/', (req, res) => {
    res.send("Express app is running");
});

// Start server
app.listen(port, (error) => {
    if (!error) {
        console.log(`Server is running on port ${port}`);
    } else {
        console.log(error);
    }
});